package Servidor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;
import java.util.TreeMap;

public class Fugaz  extends Thread {
	private static TreeMap<Integer, String> proverbio = new TreeMap<Integer, String>();
	private String mensaje_peticion;
	private String mensaje;
	private int linea;
	private int puerto; 
	private String fichero;
	
	public Fugaz(int puerto, String fichero,int linea,TreeMap<Integer, String> proverbio){
		this.puerto=puerto;
		this.fichero=fichero;
		this.linea=linea;	
		this.proverbio=proverbio;
	}
	 
	 public void run(){
		 
		 try {
		
			 
		      DatagramSocket clienteUDP = new DatagramSocket(puerto);
		      byte[] mensaje_recibido = new byte[1024];
		      byte[] mensaje_enviar = new byte[1024];
		    
		      do{
		    	 
		        // Construimos el DatagramPacket para recibir peticiones
		        DatagramPacket peticion = new DatagramPacket(mensaje_recibido, mensaje_recibido.length);

		        // Leemos la peticion del DatagramSocket
		        clienteUDP.receive(peticion);
		        mensaje_peticion=mensaje(peticion.getData());
		    //    System.out.println("Se ha recibido y se esta atendiendo una peticion.");
		        
		        //COMPROVAMOS QUE MENSAJE DE PETICION SEA EL CORRESPONDIETE.
		        System.out.println("Peticion recibida: "+ mensaje_peticion.trim());
		        if (mensaje_peticion.trim().equalsIgnoreCase("Fugaz")){
		        	//System.out.println("Se entra en el if de give me.");
		        
		       
		        	if(linea==proverbio.size()-1){linea=0;}
		        	mensaje=proverbio_enviar(linea);
		        	linea++;
		        	mensaje_enviar=mensaje.getBytes();
		        	
		        // Construimos el DatagramPacket para enviar la respuesta
		        DatagramPacket respuesta = new DatagramPacket(mensaje_enviar, mensaje_enviar.length, peticion.getAddress(), peticion.getPort());
		      
		       
		        
		        // Enviamos la respuesta.
		        clienteUDP.send(respuesta);
		
		        }
		        else{
		        	System.out.println("Se ha recibido una peticion que no corresponde.(Mensanje de peticion del cliente.)");
		        	mensaje="Error en su peticion. Compruebe el mensaje de peticion.";
		        	mensaje_enviar=mensaje.getBytes();
		        	DatagramPacket respuesta = new DatagramPacket(mensaje_enviar, mensaje_enviar.length, peticion.getAddress(), peticion.getPort());
			        // Enviamos la respuesta.
			        clienteUDP.send(respuesta);
		        }
		        
		      }while(true);
		      

		    } catch (SocketException e) {
		      System.out.println("Socket: " + e.getMessage());
		    } catch (IOException e) {
		      System.out.println("IO: " + e.getMessage());
		    }
		 
	 }
	 
	 
	 
    public static String mensaje(byte[] mensaje_byte){
		    String mensaje = "";

		    for(int i = 0; i < mensaje_byte.length; i++)
		    {
		    	mensaje += (char)mensaje_byte[i];
		    }

		    return mensaje;    
		}
		
		
	public static String proverbio_enviar(int linea){
			String mensaje=null;
			mensaje=proverbio.get(linea);	
			return mensaje;
		}

		
		
		
}
