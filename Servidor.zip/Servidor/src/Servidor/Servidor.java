package Servidor;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;
import java.util.TreeMap;



public class Servidor {
	static int puerto=0; //
	static String fichero;
	String peticion=null;
	static String mensaje_peticion;
	static String mensaje;
	static TreeMap<Integer, String> proverbio = new TreeMap<Integer, String>();
	static boolean conection=true;
	
	public static void main(String[] args) {
		if(args.length==2){
		//DECLARAMOS LAS VARIABLES QUE VAMOS A EMPLEAR.
		int linea=0;
		String fichero=args[1];
		int puerto=Integer.parseInt(args[0]);
		
		//CREAMOS UN TREEMAP DEL CON LOS PROVERBIOS
		leer(fichero);
		//IMPRIMIMOS POR PANTALLA EL PUERTO Y EL FICHERO CON EL QUE TRABAJAMOS.
		System.out.println("Puerto: "+puerto+" Fichero: "+fichero);
		
		//DECLARAMOS EL SERVERSOCKET Y EL SOCKET PARA LOS CLIENTES PERMANTENTES(TCP)
		ServerSocket servidor=null;
		Socket peticion=null;
		
		//CREAMOS UN HILO PARA LOS FUGAZ(UDP).
		Thread atenderF=new Fugaz(puerto,fichero,linea,proverbio);
		atenderF.start();//EJECUTAMOS EL HILO.
		
		
		//CREAMOS UNA INSTACIA DE SERVERSOKET Y LE PASAMOS EL PUERTO CON EL QUE TRABAJAMOS.
		try {
			servidor = new ServerSocket(puerto);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		while(true){
	
				try {
					//ESCUCHAMOS LAS PETICIONES 
					peticion = servidor.accept();
					//CREAMOS UN HILO PARA LOS CLIENTES PERSISTENTES(TCP)
					Thread atenderP=new Persistente(puerto,proverbio,peticion);
					atenderP.start();//EJECUTAMOS EL HILO.
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		
		}
		}
		else{
			System.out.println("EJECUTAR SERVIDOR: ");
			System.out.println("JAVA SERVIDOR.JAVA PUERTO ARCHIVO.TXT");
			System.out.println("EJEMPLO:JAVA SERVIDOR.JAVA 5026 PROVERBIOS.TXT");
		}
		
		 
		 
	}
	
	
	//Pasamos el mensaje de byte [] a String
		public static String mensaje(byte[] mensaje_byte){
		    String mensaje = "";

		    for(int i = 0; i < mensaje_byte.length; i++)
		    {
		    	mensaje += (char)mensaje_byte[i];
		    }

		    return mensaje;    
		}
		
		//EXTREAMOS LOS PROVERBIOS LINEA A LINEA Y CREAMOS UNA TREEMAP.
		public static void leer(String fichero){
			Scanner txt=null;
			int key=0;
			try {
				txt = new Scanner(new FileInputStream(fichero));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String linea = null;
			
			while(txt.hasNextLine()){
				linea = txt.nextLine();
				proverbio.put(key,linea);
				key++;
				
				}
			
		}
		
		//LE PASAMOS LA LINEA Y NOS DEVUELVE EL PROVERBIO EN UN STRING.
		public static String proverbio_enviar(int linea){
			String mensaje=null;
			mensaje=proverbio.get(linea);	
			return mensaje;
		}
		
		
	}
	

