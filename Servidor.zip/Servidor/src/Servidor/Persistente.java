package Servidor;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.TreeMap;

public class Persistente extends Thread {
	private String mensaje_cliente;
	private String mensaje_enviar;
	private ServerSocket servidor;
	private int linea=0;
	private int puerto;
	private Socket peticion;
	private TreeMap<Integer, String> proverbio;
	public Persistente(int puerto,TreeMap<Integer, String> proverbio,Socket peticion){
		this.puerto=puerto;
		this.proverbio=proverbio;
		this.peticion=peticion;
	}
	
	public  void run(){
		
        
		  try{
		       
		        while(true){
		           DataInputStream mensaje = new DataInputStream(peticion.getInputStream());
		           mensaje_cliente = mensaje.readUTF();
		           System.out.println("Peticion recibida: " + mensaje_cliente.trim());
		           
		           
		           DataOutputStream respuesta = new DataOutputStream(peticion.getOutputStream());
		           	
		           if (mensaje_cliente.trim().equalsIgnoreCase("Persistente")){
		           if(linea==proverbio.size()-1){linea=0;}	  
		           mensaje_enviar = proverbio_enviar(linea,proverbio);
		           respuesta.writeUTF(mensaje_enviar);
		           linea++;
		           
		           
		           }
		         
		           else{
		           	System.out.println("Mensaje de peticion incorrecto.");
		           	mensaje_enviar="Error en su peticion. Compruebe el mensaje de peticion.";
		           	respuesta.writeBytes(mensaje_enviar);
		          
		           }
		           
		       	 
		  	     }
		        
		        }catch (Exception ex) {
		 	        //ex.printStackTrace( );
		        	System.out.println("Cliente desconectado.");
		        }
	
		
	}
	
	public static String proverbio_enviar(int linea,TreeMap<Integer, String> proverbio){
		String mensaje=null;
		mensaje=proverbio.get(linea);	
		return mensaje;
	}

}
